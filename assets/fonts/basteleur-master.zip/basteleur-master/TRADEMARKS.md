Basteleur is a trademark of Keussel.
